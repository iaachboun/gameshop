<?php include 'header.php';?>

<!-- eerste sectie-->
    <div class="row eerste">
        <div class="col">
            <h1>GAMES SHOP</h1>
            <p>The latest games and consoles</p>
            <div class="knoppen">
                <button class="btn links">Bekijk ons aanbod</button>
                <button class="btn rechts">Neem contact op</button>
            </div>
        </div>
    </div>

<!--  tweede sectie  -->
<div class="container">
    <div class="row tweede">
        <div class="col-12">
            <h3>Ons aanbod</h3>
            <hr>
        </div>
        <div class="col-sm-3">
            <img src="view/assets/images/ps2.jpg" width="100%">
            <p>ahhaahha</p>
        </div>
        <div class="col-sm-3">
            <img src="view/assets/images/ps3.jpg" width="100%">
            <p>ahhaahha</p>
        </div>
        <div class="col-sm-3">
            <img src="view/assets/images/ps4.jpg" width="100%">
            <p>ahhaahha</p>
        </div>
        <div class="col-sm-3">
            <img src="view/assets/images/switchlite.jpg" width="100%">
            <p>ahhaahha</p>
        </div>
    </div>
</div>




<?php include 'footer.php'; ?>